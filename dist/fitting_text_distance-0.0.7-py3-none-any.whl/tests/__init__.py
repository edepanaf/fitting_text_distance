"""Unit test package for fitting_text_distance."""
